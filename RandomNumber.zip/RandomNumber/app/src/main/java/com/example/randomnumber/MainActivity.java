package com.example.randomnumber;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onButtonClick (View view){
        TextView res = (TextView)findViewById(R.id.result);
        EditText n1 = (EditText)findViewById(R.id.Num1);
        EditText n2 = (EditText)findViewById(R.id.Num2);

        int num1 = Integer.parseInt(n1.getText().toString());
        int num2 = Integer.parseInt(n2.getText().toString());
        int diff = num2-num1;
        Random random = new Random();
        int i = random.nextInt(diff+1);
        i+=num1;
        res.setText(Integer.toString(i));
    }
    public void onClick(View view) {
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        startActivity(intent);
    }
}

